#pragma once
#include "../../../ArduinoCore-API/api/Stream.h"
