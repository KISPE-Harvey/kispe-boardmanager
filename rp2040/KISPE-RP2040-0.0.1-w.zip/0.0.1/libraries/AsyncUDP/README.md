# AsyncUDP Library for RP2040 Arduino-Pico

The library is easy to use and includes support for Unicast, Broadcast and Multicast environments.

Ported (very minimal changes) from @me-no-dev's [original for the ESP8266](https://github.com/me-no-dev/ESPAsyncUDP).
