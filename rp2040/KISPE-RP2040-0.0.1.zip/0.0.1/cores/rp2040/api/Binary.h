#pragma once
#include "../../../ArduinoCore-API/api/Binary.h"
