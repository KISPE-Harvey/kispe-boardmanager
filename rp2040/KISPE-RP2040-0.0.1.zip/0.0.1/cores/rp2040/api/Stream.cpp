#include "../../../ArduinoCore-API/api/Stream.cpp"
