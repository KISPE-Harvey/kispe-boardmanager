#pragma once
#include "../../../ArduinoCore-API/api/WCharacter.h"
