#ifdef USBCON

#include "usbd_ioreq.c"

#endif /* USBCON */
