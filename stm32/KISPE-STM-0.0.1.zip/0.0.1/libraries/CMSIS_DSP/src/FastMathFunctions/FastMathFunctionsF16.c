#include "../Source/FastMathFunctions/FastMathFunctionsF16.c"
